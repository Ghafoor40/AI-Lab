from flask import Flask, render_template, request

app = Flask(__name__)

# Home Page
@app.route('/')
def home():
    return render_template("index.html")

# Prediction Logic (Manual AI Logic)
@app.route('/predict', methods=['POST'])
def predict():
    try:
        f1 = float(request.form['f1'])
        f2 = float(request.form['f2'])
        f3 = float(request.form['f3'])
        f4 = float(request.form['f4'])
        f5 = float(request.form['f5'])

        # Simple logic (demo AI)
        score = f1 + f2 + f3 + f4 + f5

        if score > 50:
            result = "Survived"
        else:
            result = "Not Survived"

        return render_template("index.html", prediction_text=result)

    except Exception as e:
        return render_template("index.html", prediction_text=f"Error: {e}")

if __name__ == "__main__":
    app.run(debug=True)
from flask import Flask
app = Flask(__name__)